import React from "react";
import "./Offer.css";

function Offer() {
  return <div className="offer-container"></div>;
}

export default Offer;

import React from "react";
import "./TrackOrders.css";

function TrackOrders() {
  return (
    <div className="Track-Orders-Container">
      <img src="Images/Track_Orders_image.png"></img>
    </div>
  );
}

export default TrackOrders;
